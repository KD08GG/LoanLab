import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, User } from 'lucide-angular';
import { UsuariosService, Usuario } from '../../../services/usuarios';

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './usuarios.html',
  styleUrls: ['./usuarios.css']
})
export class Usuarios implements OnInit, OnDestroy {
  readonly User = User;

  nombreUsuario = 'Usuario';
  tabActivo = 'todos';
  usuarios: Usuario[] = [];
  cargando = true;
  error = false;

  private eventSource!: EventSource;

  constructor(
    private usuariosService: UsuariosService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.nombreUsuario = this.obtenerNombreGuardado();

    this.usuariosService.getUsuarios().subscribe({
      next: (data) => {
        this.usuarios = Array.isArray(data) ? data : [];
        this.cargando = false;

        this.conectarSSE();

        this.cdr.detectChanges();
      },
      error: () => {
        this.error = true;
        this.cargando = false;
        this.cdr.detectChanges();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.eventSource) {
      this.eventSource.close();
    }
  }

  private conectarSSE(): void {
    this.eventSource = new EventSource('http://localhost:8000/api/usuarios/stream/');

    this.eventSource.onmessage = (event) => {
      console.log('Evento SSE usuarios:', event.data);

      this.usuariosService.getUsuarios().subscribe({
        next: (data) => {
          this.usuarios = Array.isArray(data) ? [...data] : [];
          this.cdr.detectChanges();
        },
        error: (err) => {
          console.error('Error recargando usuarios por SSE:', err);
        }
      });
    };

    this.eventSource.onerror = (error) => {
      console.error('Error SSE usuarios:', error);
    };
  }

  private obtenerNombreGuardado(): string {
    const nombre = localStorage.getItem('nombre');
    if (nombre) return nombre;

    const usuarioGuardado = localStorage.getItem('usuario');
    if (!usuarioGuardado) return 'Usuario';

    try {
      const usuario = JSON.parse(usuarioGuardado);
      return usuario?.nombre_usuario || usuario?.nombre || usuario?.username || 'Usuario';
    } catch (error) {
      console.error('Error al leer usuario desde localStorage:', error);
      return 'Usuario';
    }
  }

  cambiarTab(tab: string): void {
    this.tabActivo = tab;
    this.cdr.detectChanges();
  }

  get usuariosFiltrados(): Usuario[] {
    if (this.tabActivo === 'todos') return this.usuarios;
    return this.usuarios.filter((u) => u.estado_usuario === this.tabActivo);
  }

  obtenerClaseBadge(estado: string): string {
    const clases: { [key: string]: string } = {
      activo: 'badge badge--green',
      fuera: 'badge badge--gray',
      suspendido: 'badge badge--red',
      prestamo: 'badge badge--orange'
    };
    return clases[estado] || 'badge';
  }

  obtenerTextoEstado(estado: string): string {
    const textos: { [key: string]: string } = {
      activo: 'Activo',
      fuera: 'Fuera',
      suspendido: 'Suspendido',
      prestamo: 'Préstamo extendido'
    };
    return textos[estado] || estado;
  }

  obtenerUltimoAcceso(fecha: string | null): string {
    if (!fecha) return 'Sin acceso';
    const d = new Date(fecha);
    return d.toLocaleString('es-MX');
  }
}
